package com.budgetgo.backend.controller;

import com.budgetgo.backend.entity.Trip;
import com.budgetgo.backend.repository.TripRepository;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/trips")
public class TripController {

    @Autowired
    private TripRepository tripRepository;

    @GetMapping
    public ResponseEntity<List<Trip>> getAllTrips(@RequestParam(required = false) Long userId) {
        if (userId != null) {
            return ResponseEntity.ok(tripRepository.findByUserIdOrderByCreatedAtDesc(userId));
        }
        return ResponseEntity.ok(tripRepository.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Trip> getTripById(@PathVariable Long id) {
        Optional<Trip> trip = tripRepository.findById(id);
        return trip.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<?> createTrip(@Valid @RequestBody TripRequest request) {
        try {
            Trip trip = new Trip(
                    request.tripName(),
                    request.destination(),
                    LocalDate.parse(request.startDate()),
                    LocalDate.parse(request.endDate()),
                    request.budget(),
                    request.travelers(),
                    request.description(),
                    request.mood(),
                    request.userId()
            );
            trip.setStatus(request.status() != null ? request.status() : "Planning");
            Trip savedTrip = tripRepository.save(trip);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedTrip);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", "Failed to create trip: " + e.getMessage()));
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateTrip(@PathVariable Long id, @Valid @RequestBody TripRequest request) {
        Optional<Trip> tripOpt = tripRepository.findById(id);
        if (tripOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        try {
            Trip trip = tripOpt.get();
            trip.setTripName(request.tripName());
            trip.setDestination(request.destination());
            trip.setStartDate(LocalDate.parse(request.startDate()));
            trip.setEndDate(LocalDate.parse(request.endDate()));
            trip.setBudget(request.budget());
            trip.setTravelers(request.travelers());
            trip.setDescription(request.description());
            trip.setMood(request.mood());
            if (request.status() != null) {
                trip.setStatus(request.status());
            }

            Trip updatedTrip = tripRepository.save(trip);
            return ResponseEntity.ok(updatedTrip);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", "Failed to update trip: " + e.getMessage()));
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteTrip(@PathVariable Long id) {
        if (!tripRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        tripRepository.deleteById(id);
        return ResponseEntity.ok(Map.of("message", "Trip deleted successfully"));
    }

    public record TripRequest(
            @NotBlank String tripName,
            @NotBlank String destination,
            @NotBlank String startDate,
            @NotBlank String endDate,
            @NotNull Double budget,
            @NotNull Integer travelers,
            String description,
            String mood,
            @NotNull Long userId,
            String status
    ) {}
}


package com.budgetgo.backend.controller;

import com.budgetgo.backend.entity.Booking;
import com.budgetgo.backend.repository.BookingRepository;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {

    @Autowired
    private BookingRepository bookingRepository;

    @GetMapping
    public ResponseEntity<List<Booking>> getAllBookings(
            @RequestParam(required = false) Long userId,
            @RequestParam(required = false) Long tripId) {
        if (userId != null && tripId != null) {
            return ResponseEntity.ok(bookingRepository.findByUserIdAndTripId(userId, tripId));
        } else if (userId != null) {
            return ResponseEntity.ok(bookingRepository.findByUserIdOrderByCreatedAtDesc(userId));
        } else if (tripId != null) {
            return ResponseEntity.ok(bookingRepository.findByTripId(tripId));
        }
        return ResponseEntity.ok(bookingRepository.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Booking> getBookingById(@PathVariable Long id) {
        Optional<Booking> booking = bookingRepository.findById(id);
        return booking.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<?> createBooking(@Valid @RequestBody BookingRequest request) {
        try {
            Booking booking = new Booking(
                    request.type(),
                    request.name(),
                    request.location(),
                    request.checkIn() != null ? LocalDate.parse(request.checkIn()) : null,
                    request.checkOut() != null ? LocalDate.parse(request.checkOut()) : null,
                    request.price(),
                    request.status() != null ? request.status() : "Pending",
                    request.tripId(),
                    request.userId()
            );
            booking.setDuration(request.duration());
            booking.setImage(request.image());
            Booking savedBooking = bookingRepository.save(booking);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedBooking);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", "Failed to create booking: " + e.getMessage()));
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateBooking(@PathVariable Long id, @Valid @RequestBody BookingRequest request) {
        Optional<Booking> bookingOpt = bookingRepository.findById(id);
        if (bookingOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        try {
            Booking booking = bookingOpt.get();
            booking.setType(request.type());
            booking.setName(request.name());
            booking.setLocation(request.location());
            if (request.checkIn() != null) {
                booking.setCheckIn(LocalDate.parse(request.checkIn()));
            }
            if (request.checkOut() != null) {
                booking.setCheckOut(LocalDate.parse(request.checkOut()));
            }
            booking.setPrice(request.price());
            if (request.status() != null) {
                booking.setStatus(request.status());
            }
            booking.setDuration(request.duration());
            booking.setImage(request.image());

            Booking updatedBooking = bookingRepository.save(booking);
            return ResponseEntity.ok(updatedBooking);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", "Failed to update booking: " + e.getMessage()));
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteBooking(@PathVariable Long id) {
        if (!bookingRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        bookingRepository.deleteById(id);
        return ResponseEntity.ok(Map.of("message", "Booking deleted successfully"));
    }

    public record BookingRequest(
            @NotBlank String type,
            @NotBlank String name,
            @NotBlank String location,
            String checkIn,
            String checkOut,
            @NotNull Double price,
            String status,
            Long tripId,
            @NotNull Long userId,
            String duration,
            String image
    ) {}
}


package com.budgetgo.backend.controller;

import com.budgetgo.backend.entity.Invitation;
import com.budgetgo.backend.entity.TripMember;
import com.budgetgo.backend.entity.User;
import com.budgetgo.backend.repository.InvitationRepository;
import com.budgetgo.backend.repository.TripMemberRepository;
import com.budgetgo.backend.repository.UserRepository;
import com.budgetgo.backend.service.JwtService;
import com.budgetgo.backend.service.PasswordService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api")
public class AuthController {

  @Autowired
  private UserRepository userRepository;

  @Autowired
  private PasswordService passwordService;

  @Autowired
  private JwtService jwtService;

  @Autowired
  private InvitationRepository invitationRepository;

  @Autowired
  private TripMemberRepository tripMemberRepository;

  @PostMapping("/login")
  public ResponseEntity<?> login(@Valid @RequestBody LoginRequest request) {
    try {
      Optional<User> userOpt = userRepository.findByEmail(request.email());
      
      if (userOpt.isEmpty()) {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
            .body(Map.of("error", "Invalid email or password"));
      }

      User user = userOpt.get();
      
      // For demo users, allow plain password check, otherwise verify hashed password
      boolean passwordValid = false;
      if (user.getPassword().startsWith("$2a$") || user.getPassword().startsWith("$2b$")) {
        // Hashed password
        passwordValid = passwordService.verifyPassword(request.password(), user.getPassword());
      } else {
        // Plain password (for demo users)
        passwordValid = user.getPassword().equals(request.password());
      }
      
      if (!passwordValid) {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
            .body(Map.of("error", "Invalid email or password"));
      }

      String token = jwtService.generateToken(user.getId(), user.getEmail(), user.getRole());

      LoginResponse response = new LoginResponse(
          user.getId(),
          user.getName(),
          user.getEmail(),
          user.getRole(),
          token
      );

      return ResponseEntity.ok(response);
    } catch (Exception e) {
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
          .body(Map.of("error", "Login failed: " + e.getMessage()));
    }
  }

  @PostMapping("/register")
  public ResponseEntity<?> register(@Valid @RequestBody RegisterRequest request) {
    try {
      if (userRepository.existsByEmail(request.email())) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
            .body(Map.of("error", "User with this email already exists"));
      }

      if (request.password().length() < 6) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
            .body(Map.of("error", "Password must be at least 6 characters"));
      }

      String hashedPassword = passwordService.hashPassword(request.password());
      String role = request.role() != null && !request.role().isEmpty() ? request.role() : "user";

      User newUser = new User(request.name(), request.email(), hashedPassword, role);
      User savedUser = userRepository.save(newUser);

      // Handle invitation if token is provided
      Long tripId = null;
      if (request.invitationToken() != null && !request.invitationToken().isEmpty()) {
        Optional<Invitation> invitationOpt = invitationRepository.findByToken(request.invitationToken());
        if (invitationOpt.isPresent()) {
          Invitation invitation = invitationOpt.get();
          
          // Verify email matches invitation
          if (invitation.getEmail().equalsIgnoreCase(savedUser.getEmail()) 
              && !invitation.isExpired() 
              && "pending".equals(invitation.getStatus())) {
            
            // Add user to trip members
            if (!tripMemberRepository.existsByTripIdAndUserId(invitation.getTripId(), savedUser.getId())) {
              TripMember tripMember = new TripMember(
                  invitation.getTripId(),
                  savedUser.getId(),
                  "member",
                  "active"
              );
              tripMemberRepository.save(tripMember);
              tripId = invitation.getTripId();
            }

            // Mark invitation as accepted
            invitation.setStatus("accepted");
            invitation.setAcceptedAt(LocalDateTime.now());
            invitationRepository.save(invitation);
          }
        }
      }

      String token = jwtService.generateToken(savedUser.getId(), savedUser.getEmail(), savedUser.getRole());

      LoginResponse response = new LoginResponse(
          savedUser.getId(),
          savedUser.getName(),
          savedUser.getEmail(),
          savedUser.getRole(),
          token
      );

      Map<String, Object> responseBody = Map.of(
          "id", response.id(),
          "name", response.name(),
          "email", response.email(),
          "role", response.role(),
          "token", response.token()
      );

      if (tripId != null) {
        return ResponseEntity.status(HttpStatus.CREATED).body(
            Map.of(
                "user", responseBody,
                "tripId", tripId,
                "message", "Registration successful and added to trip"
            )
        );
      }

      return ResponseEntity.status(HttpStatus.CREATED).body(responseBody);
    } catch (Exception e) {
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
          .body(Map.of("error", "Registration failed: " + e.getMessage()));
    }
  }

  public record LoginRequest(
      @Email(message = "Invalid email") String email,
      @NotBlank(message = "Password is required") String password
  ) { }

  public record RegisterRequest(
      @NotBlank(message = "Name is required") String name,
      @Email(message = "Invalid email") String email,
      @NotBlank(message = "Password is required") String password,
      String role,
      String invitationToken
  ) { }

  public record LoginResponse(
      Long id,
      String name,
      String email,
      String role,
      String token
  ) { }
}


package com.budgetgo.backend.controller;

import com.budgetgo.backend.entity.Expense;
import com.budgetgo.backend.repository.ExpenseRepository;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/expenses")
public class ExpenseController {

    @Autowired
    private ExpenseRepository expenseRepository;

    @GetMapping
    public ResponseEntity<List<Expense>> getAllExpenses(
            @RequestParam(required = false) Long userId,
            @RequestParam(required = false) Long tripId) {
        if (userId != null && tripId != null) {
            return ResponseEntity.ok(expenseRepository.findByUserIdAndTripId(userId, tripId));
        } else if (userId != null) {
            return ResponseEntity.ok(expenseRepository.findByUserIdOrderByDateDesc(userId));
        } else if (tripId != null) {
            return ResponseEntity.ok(expenseRepository.findByTripId(tripId));
        }
        return ResponseEntity.ok(expenseRepository.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Expense> getExpenseById(@PathVariable Long id) {
        Optional<Expense> expense = expenseRepository.findById(id);
        return expense.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<?> createExpense(@Valid @RequestBody ExpenseRequest request) {
        try {
            Expense expense = new Expense(
                    request.category(),
                    request.amount(),
                    LocalDate.parse(request.date()),
                    request.description(),
                    request.splitAmong() != null ? request.splitAmong() : 1,
                    request.paidBy(),
                    request.tripId(),
                    request.userId()
            );
            Expense savedExpense = expenseRepository.save(expense);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedExpense);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", "Failed to create expense: " + e.getMessage()));
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateExpense(@PathVariable Long id, @Valid @RequestBody ExpenseRequest request) {
        Optional<Expense> expenseOpt = expenseRepository.findById(id);
        if (expenseOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        try {
            Expense expense = expenseOpt.get();
            expense.setCategory(request.category());
            expense.setAmount(request.amount());
            expense.setDate(LocalDate.parse(request.date()));
            expense.setDescription(request.description());
            expense.setSplitAmong(request.splitAmong() != null ? request.splitAmong() : 1);
            expense.setPaidBy(request.paidBy());

            Expense updatedExpense = expenseRepository.save(expense);
            return ResponseEntity.ok(updatedExpense);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", "Failed to update expense: " + e.getMessage()));
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteExpense(@PathVariable Long id) {
        if (!expenseRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        expenseRepository.deleteById(id);
        return ResponseEntity.ok(Map.of("message", "Expense deleted successfully"));
    }

    public record ExpenseRequest(
            @NotBlank String category,
            @NotNull Double amount,
            @NotBlank String date,
            @NotBlank String description,
            Integer splitAmong,
            String paidBy,
            Long tripId,
            @NotNull Long userId
    ) {}
}


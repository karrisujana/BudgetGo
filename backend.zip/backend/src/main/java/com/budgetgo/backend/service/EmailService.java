package com.budgetgo.backend.service;

import org.springframework.stereotype.Service;
import java.util.logging.Logger;

@Service
public class EmailService {
    private static final Logger logger = Logger.getLogger(EmailService.class.getName());

    // In production, integrate with actual email service (SendGrid, AWS SES, etc.)
    public void sendInvitationEmail(String toEmail, String tripName, String invitationLink, String invitedBy) {
        try {
            String subject = "You've been invited to join a trip: " + tripName;
            String body = buildInvitationEmailBody(tripName, invitationLink, invitedBy);
            
            // Log email for development (in production, send actual email)
            logger.info("=== EMAIL SENT ===");
            logger.info("To: " + toEmail);
            logger.info("Subject: " + subject);
            logger.info("Body:\n" + body);
            logger.info("==================");
            
            // TODO: In production, use actual email service:
            // Example with JavaMailSender:
            // MimeMessage message = mailSender.createMimeMessage();
            // MimeMessageHelper helper = new MimeMessageHelper(message, true);
            // helper.setTo(toEmail);
            // helper.setSubject(subject);
            // helper.setText(body, true);
            // mailSender.send(message);
            
        } catch (Exception e) {
            logger.severe("Failed to send invitation email: " + e.getMessage());
            // In production, don't throw - use async email queue
        }
    }

    private String buildInvitationEmailBody(String tripName, String invitationLink, String invitedBy) {
        return String.format(
            "<html><body style='font-family: Arial, sans-serif; padding: 20px;'>" +
            "<h2 style='color: #667eea;'>You've been invited to join a trip!</h2>" +
            "<p><strong>%s</strong> has invited you to join the trip: <strong>%s</strong></p>" +
            "<p>Click the link below to register and join the trip:</p>" +
            "<div style='margin: 20px 0;'>" +
            "<a href='%s' style='background-color: #667eea; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; display: inline-block;'>Join Trip</a>" +
            "</div>" +
            "<p style='color: #666; font-size: 12px;'>This invitation will expire in 7 days.</p>" +
            "<p style='color: #666; font-size: 12px;'>If you didn't expect this invitation, you can safely ignore this email.</p>" +
            "</body></html>",
            invitedBy, tripName, invitationLink
        );
    }
}


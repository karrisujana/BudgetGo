package com.budgetgo.backend.controller;

import com.budgetgo.backend.entity.TripMember;
import com.budgetgo.backend.repository.TripMemberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/trip-members")
public class TripMemberController {

    @Autowired
    private TripMemberRepository tripMemberRepository;

    @GetMapping
    public ResponseEntity<List<TripMember>> getTripMembers(
            @RequestParam(required = false) Long tripId,
            @RequestParam(required = false) Long userId) {
        if (tripId != null) {
            return ResponseEntity.ok(tripMemberRepository.findByTripId(tripId));
        } else if (userId != null) {
            return ResponseEntity.ok(tripMemberRepository.findByUserId(userId));
        }
        return ResponseEntity.ok(tripMemberRepository.findAll());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> removeMember(@PathVariable Long id) {
        if (!tripMemberRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        tripMemberRepository.deleteById(id);
        return ResponseEntity.ok(java.util.Map.of("message", "Member removed successfully"));
    }
}

